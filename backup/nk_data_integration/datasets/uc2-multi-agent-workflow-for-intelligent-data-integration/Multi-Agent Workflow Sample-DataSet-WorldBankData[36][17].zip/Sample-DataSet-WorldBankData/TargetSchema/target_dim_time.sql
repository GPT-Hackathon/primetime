CREATE TABLE `project.dataset.dim_time` (
  year INT64 NOT NULL,
  year_key STRING
);
