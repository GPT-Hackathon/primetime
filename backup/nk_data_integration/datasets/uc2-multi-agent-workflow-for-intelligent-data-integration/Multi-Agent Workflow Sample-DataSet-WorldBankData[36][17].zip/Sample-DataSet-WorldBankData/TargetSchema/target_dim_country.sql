CREATE TABLE `project.dataset.dim_country` (
  country_key STRING NOT NULL,
  country_name STRING,
  iso3 STRING,
  region STRING,
  income_group STRING
);
