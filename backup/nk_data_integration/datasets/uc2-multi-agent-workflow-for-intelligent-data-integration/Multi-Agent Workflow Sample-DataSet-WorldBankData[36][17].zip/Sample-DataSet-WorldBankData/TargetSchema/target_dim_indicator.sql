CREATE TABLE `project.dataset.dim_indicator` (
  indicator_code STRING NOT NULL,
  indicator_name STRING,
  topic STRING
);
